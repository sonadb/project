export interface Productd {
      productId:Number;
      productName:string;
      productPrice:Number;
      productDiscription:string;
      productImage:string;
      productImage1:string;
      productImage2:string;
      productImage3:string;
      productCategoryID:Number;
      tags:string;
}


