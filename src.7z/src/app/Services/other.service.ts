import { Injectable } from '@angular/core';
import { CartServiceService } from './cart-service.service';

@Injectable({
  providedIn: 'root'
})
export class OtherService {

  public searchterm:string='';

  constructor() { }

 // searchkey


}

