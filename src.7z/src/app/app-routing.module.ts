import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddToCartComponent } from './Component/cart/add-to-cart/add-to-cart.component';

import { CheckoutComponent } from './Component/cart/checkout/checkout.component';
import { HomeComponent } from './Component/home/home.component';

const routes: Routes = [
  {
    component:HomeComponent,
     path:''
    },
    {
    component: AddToCartComponent,
     path:'addtocart'

   },
   {
    component:CheckoutComponent,
    path:'checkout'
   }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
